let photoCount = 0;
let selectedHex = "#ffffff";

function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

async function initBooth(hex) {
    selectedHex = hex;
    document.getElementById('photo-strip').style.backgroundColor = hex;
    showScreen('booth');

    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    document.getElementById('video').srcObject = stream;
}

async function captureSequence() {
    if (photoCount >= 4) return;

    const btn = document.getElementById('shoot-btn');
    const timer = document.getElementById('timer');

    btn.disabled = true;
    timer.style.display = 'block';

    for (let i = 3; i > 0; i--) {
        timer.innerText = i;
        await new Promise(r => setTimeout(r, 800));
    }

    timer.style.display = 'none';

    const video = document.getElementById('video');
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0);

    document.getElementById(`img-${photoCount}`).src = canvas.toDataURL();

    photoCount++;

    if (photoCount < 4) {
        btn.disabled = false;
    } else {
        btn.innerText = "FINISHED";
        document.getElementById('save-btn').disabled = false;
    }
}

function downloadFinalStrip() {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    canvas.width = 400;
    canvas.height = 1100;

    ctx.fillStyle = selectedHex;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < 4; i++) {
        const img = document.getElementById(`img-${i}`);
        if (img.src) {
            ctx.drawImage(img, 30, 40 + i * 240, 340, 220);
        }
    }

    const link = document.createElement('a');
    link.download = 'photo.png';
    link.href = canvas.toDataURL();
    link.click();
}